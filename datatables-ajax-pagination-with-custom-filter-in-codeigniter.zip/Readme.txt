Author: Yogesh singh
Author URL: http://makitweb.com/
Author Email: makitweb@gmail.com
Tutorial Link: http://makitweb.com/datatables-ajax-pagination-with-custom-filter-in-codeigniter/

Instructions - 

* Import SQL
Import attached users.sql file in your MySQL database

* base_url
Rename the folder and edit $config['base_url'] in application/config/config.php

* Database connection
Update database connection in application/config/database.php

